{\rtf1\ansi\ansicpg1252\cocoartf1404\cocoasubrtf470
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fswiss\fcharset0 ArialMT;}
{\colortbl;\red255\green255\blue255;\red19\green0\blue155;\red193\green193\blue193;\red100\green100\blue100;
}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0  This dataset contains the asymmetric carp instances used in \

\itap1\trowd \taflags0 \trgaph108\trleft-108 \trbrdrt\brdrnil \trbrdrl\brdrnil \trbrdrt\brdrnil \trbrdrr\brdrnil 
\clvertalc \clshdrawnil \clwWidth9520\clftsWidth3 \clmart10 \clmarl10 \clmarb10 \clmarr10 \clbrdrt\brdrnil \clbrdrl\brdrnil \clbrdrb\brdrs\brdrw20\brdrcf3 \clbrdrr\brdrnil \clpadt160 \clpadl320 \clpadb160 \clpadr320 \gaph\cellx8640
\pard\intbl\itap1\pardeftab720\partightenfactor0
{\field{\*\fldinst{HYPERLINK "https://scholar.google.it/citations?view_op=view_citation&hl=it&user=5rOdaqAAAAAJ&cstart=120&sortby=pubdate&citation_for_view=5rOdaqAAAAAJ:hqOjcs7Dif8C"}}{\fldrslt 
\f1\fs32 \cf2 \expnd0\expndtw0\kerning0
A branch-and-bound algorithm for the capacitated vehicle routing problem on directed graphs}}
\f1\fs26 \cf4 \expnd0\expndtw0\kerning0
\
M Fischetti, P Toth, D Vigo\
\
The format is inspired to that of TSPLIB and the distances are stored as full matrix.\cell \lastrow\row
}